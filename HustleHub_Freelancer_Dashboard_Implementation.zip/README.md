# MERN Auth — Login & Registration System

A full-stack authentication system with JWT, bcrypt, and a premium dark glassmorphism UI.

## Stack

| Layer | Tech |
|---|---|
| Database | MongoDB + Mongoose |
| Backend | Node.js + Express |
| Frontend | React 18 + Vite |
| Auth | JWT (7-day tokens) + bcryptjs |

## Getting Started

### Prerequisites
- Node.js 18+
- MongoDB (local or Atlas)

### 1. Configure the backend

```bash
cd server
```

Edit `.env`:
```
MONGO_URI=mongodb://localhost:27017/mern-auth
JWT_SECRET=your_super_secret_here
PORT=5000
```

### 2. Start the backend

```bash
cd server
npm install
npm run dev
```

The API will run at `http://localhost:5000`

### 3. Start the frontend

```bash
cd client
npm install
npm run dev
```

The app will open at `http://localhost:5173`

## API Endpoints

| Method | Route | Access | Description |
|---|---|---|---|
| POST | `/api/auth/register` | Public | Register new user |
| POST | `/api/auth/login` | Public | Login, returns JWT |
| GET | `/api/auth/user` | Private (Bearer token) | Get current user |

## Project Structure

```
mern-auth/
├── server/
│   ├── models/User.js        # Mongoose schema + bcrypt
│   ├── routes/auth.js        # Auth endpoints
│   ├── middleware/auth.js    # JWT protect middleware
│   ├── server.js             # Express entry point
│   └── .env                  # Environment config
│
└── client/
    ├── src/
    │   ├── api/axios.js          # Axios + token interceptor
    │   ├── context/AuthContext.jsx  # Global auth state
    │   ├── components/ProtectedRoute.jsx
    │   ├── pages/
    │   │   ├── Login.jsx
    │   │   ├── Register.jsx
    │   │   └── Dashboard.jsx
    │   ├── App.jsx               # Routes
    │   └── index.css             # Dark glassmorphism styles
    └── vite.config.js
```
