require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('./models/User');
const Gig = require('./models/Gig');
const Booking = require('./models/Booking');
const Transaction = require('./models/Transaction');

(async () => {
  await mongoose.connect(process.env.MONGO_URI);
  const password = 'Freelancer123!';
  let freelancer = await User.findOne({ email: 'freelancer@hustlehub.local' });
  if (!freelancer) {
    freelancer = await User.create({ name: 'Demo Freelancer', email: 'freelancer@hustlehub.local', password, role: 'freelancer', bio: 'Independent creative and web specialist.', skills: ['React', 'Design', 'Copywriting'], hourlyRate: 450, portfolioLinks: [{ label: 'Portfolio', url: 'https://example.com' }] });
  }
  let client = await User.findOne({ email: 'client@hustlehub.local' });
  if (!client) client = await User.create({ name: 'Demo Client', email: 'client@hustlehub.local', password, role: 'client' });

  const existingGigs = await Gig.find({ freelancer: freelancer._id });
  const gigs = existingGigs.length ? existingGigs : await Gig.create([
    { freelancer: freelancer._id, title: 'Responsive React Website', description: 'I will build a polished responsive React landing page with reusable sections.', category: 'Web Development', price: 3500, deliveryTime: 5 },
    { freelancer: freelancer._id, title: 'Brand Starter Kit', description: 'Logo direction, colour palette and social-ready brand assets for a small business.', category: 'Design', price: 2200, deliveryTime: 4 },
    { freelancer: freelancer._id, title: 'Website Copy Refresh', description: 'Clear, conversion-focused website copy for your core pages.', category: 'Writing', price: 1500, deliveryTime: 3 },
  ]);

  const existingBooking = await Booking.findOne({ freelancer: freelancer._id, client: client._id });
  if (!existingBooking) {
    const completed = await Booking.create({ gig: gigs[0]._id, freelancer: freelancer._id, client: client._id, requestedDate: new Date(Date.now() - 1000 * 60 * 60 * 24 * 12), amount: gigs[0].price, status: 'completed', completedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 8) });
    await Booking.create({ gig: gigs[1]._id, freelancer: freelancer._id, client: client._id, requestedDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 4), amount: gigs[1].price, status: 'pending' });
    await Transaction.create({ booking: completed._id, freelancer: freelancer._id, client: client._id, gig: gigs[0]._id, category: gigs[0].category, amount: completed.amount, status: 'completed', transactionDate: completed.completedAt });
  }

  console.log('\nDemo freelancer ready:');
  console.log('Email: freelancer@hustlehub.local');
  console.log('Password: Freelancer123!');
  await mongoose.disconnect();
})().catch((err) => { console.error(err); process.exit(1); });
