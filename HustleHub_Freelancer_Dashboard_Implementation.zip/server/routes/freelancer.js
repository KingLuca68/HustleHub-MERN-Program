const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const { authorize } = require('../middleware/roles');
const controller = require('../controllers/freelancerController');

router.use(protect, authorize('freelancer'));

router.get('/dashboard', controller.dashboard);

router.get('/gigs', controller.listGigs);
router.post('/gigs', controller.createGig);
router.get('/gigs/:id', controller.getGig);
router.put('/gigs/:id', controller.updateGig);
router.delete('/gigs/:id', controller.deleteGig);
router.get('/gigs/:id/bookings', controller.listGigBookings);

router.get('/bookings', controller.listBookings);
router.patch('/bookings/:id/accept', controller.acceptBooking);
router.patch('/bookings/:id/decline', controller.declineBooking);
router.patch('/bookings/:id/complete', controller.completeBooking);

router.get('/transactions', controller.transactions);
router.get('/transactions/export', controller.exportTransactions);
router.get('/income/summary', controller.incomeSummary);

router.get('/profile', controller.profile);
router.patch('/profile', controller.updateProfile);
router.patch('/profile/password', controller.changePassword);

module.exports = router;
