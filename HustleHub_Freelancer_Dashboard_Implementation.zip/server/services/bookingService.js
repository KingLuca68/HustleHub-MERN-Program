const Booking = require('../models/Booking');
const Transaction = require('../models/Transaction');

async function completeBooking({ bookingId, freelancerId }) {
  const booking = await Booking.findOne({ _id: bookingId, freelancer: freelancerId })
    .populate('gig', 'title category price')
    .populate('client', 'name email');

  if (!booking) {
    const error = new Error('Booking not found.');
    error.status = 404;
    throw error;
  }

  if (booking.status === 'completed') {
    return { booking, transaction: await Transaction.findOne({ booking: booking._id }) };
  }

  if (booking.status !== 'accepted') {
    const error = new Error('Only accepted bookings can be completed.');
    error.status = 409;
    throw error;
  }

  let transaction = await Transaction.findOne({ booking: booking._id });
  if (!transaction) {
    try {
      transaction = await Transaction.create({
        booking: booking._id,
        freelancer: freelancerId,
        client: booking.client._id,
        gig: booking.gig._id,
        category: booking.gig.category,
        amount: booking.amount,
        status: 'completed',
        transactionDate: new Date(),
      });
    } catch (err) {
      if (err?.code === 11000) {
        transaction = await Transaction.findOne({ booking: booking._id });
      } else {
        throw err;
      }
    }
  }

  booking.status = 'completed';
  booking.completedAt = new Date();
  await booking.save();

  return { booking, transaction };
}

module.exports = { completeBooking };
