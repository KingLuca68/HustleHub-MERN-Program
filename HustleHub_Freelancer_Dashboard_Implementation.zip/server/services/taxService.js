// Demonstration-only tax estimator. This is deliberately separate from route logic
// so the rules can be replaced later without changing the dashboard API.
const TAX_BRACKETS = [
  { limit: 20000, rate: 0.00 },
  { limit: 40000, rate: 0.10 },
  { limit: 80000, rate: 0.18 },
  { limit: Infinity, rate: 0.25 },
];

function estimateTax(taxableIncome) {
  const income = Math.max(0, Number(taxableIncome) || 0);
  let remaining = income;
  let previousLimit = 0;
  let estimatedTax = 0;
  let highestRate = 0;

  for (const bracket of TAX_BRACKETS) {
    const width = bracket.limit === Infinity ? remaining : Math.max(0, bracket.limit - previousLimit);
    const taxableAtBracket = Math.min(remaining, width);
    if (taxableAtBracket <= 0) break;

    estimatedTax += taxableAtBracket * bracket.rate;
    highestRate = bracket.rate;
    remaining -= taxableAtBracket;
    previousLimit = bracket.limit;

    if (remaining <= 0) break;
  }

  return {
    taxableIncome: Number(income.toFixed(2)),
    rateApplied: highestRate,
    ratePercent: Number((highestRate * 100).toFixed(2)),
    estimatedTax: Number(estimatedTax.toFixed(2)),
    note: 'Demonstration estimate only. This is not professional tax advice.',
  };
}

module.exports = { estimateTax };
