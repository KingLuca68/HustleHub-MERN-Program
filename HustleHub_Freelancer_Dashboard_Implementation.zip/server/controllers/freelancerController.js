const mongoose = require('mongoose');
const User = require('../models/User');
const Gig = require('../models/Gig');
const Booking = require('../models/Booking');
const Transaction = require('../models/Transaction');
const { completeBooking } = require('../services/bookingService');
const { estimateTax } = require('../services/taxService');

const safeId = (value) => mongoose.Types.ObjectId.isValid(value);

function dateRange(startDate, endDate) {
  const query = {};
  if (startDate) {
    const start = new Date(startDate);
    if (Number.isNaN(start.getTime())) throw Object.assign(new Error('Invalid start date.'), { status: 400 });
    start.setHours(0, 0, 0, 0);
    query.$gte = start;
  }
  if (endDate) {
    const end = new Date(endDate);
    if (Number.isNaN(end.getTime())) throw Object.assign(new Error('Invalid end date.'), { status: 400 });
    end.setHours(23, 59, 59, 999);
    query.$lte = end;
  }
  return query;
}

exports.dashboard = async (req, res, next) => {
  try {
    const freelancer = req.user._id;
    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    const sixMonthsAgo = new Date(now.getFullYear(), now.getMonth() - 5, 1);

    const [totalIncomeAgg, monthlyIncomeAgg, pendingBookings, recentTransactions, recentBookings, monthlyAgg] = await Promise.all([
      Transaction.aggregate([{ $match: { freelancer, status: 'completed' } }, { $group: { _id: null, total: { $sum: '$amount' } } }]),
      Transaction.aggregate([{ $match: { freelancer, status: 'completed', transactionDate: { $gte: monthStart } } }, { $group: { _id: null, total: { $sum: '$amount' } } }]),
      Booking.countDocuments({ freelancer, status: 'pending' }),
      Transaction.find({ freelancer }).sort({ transactionDate: -1 }).limit(5).populate('client', 'name').populate('gig', 'title'),
      Booking.find({ freelancer }).sort({ createdAt: -1 }).limit(5).populate('client', 'name').populate('gig', 'title'),
      Transaction.aggregate([
        { $match: { freelancer, status: 'completed', transactionDate: { $gte: sixMonthsAgo } } },
        { $group: { _id: { y: { $year: '$transactionDate' }, m: { $month: '$transactionDate' } }, income: { $sum: '$amount' } } },
        { $sort: { '_id.y': 1, '_id.m': 1 } },
      ]),
    ]);

    const trendMap = new Map(monthlyAgg.map((item) => [`${item._id.y}-${String(item._id.m).padStart(2, '0')}`, Number(item.income.toFixed(2))]));
    const incomeTrend = [];
    for (let i = 5; i >= 0; i -= 1) {
      const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      incomeTrend.push({ month: key, label: date.toLocaleString('en-ZA', { month: 'short' }), income: trendMap.get(key) || 0 });
    }

    const activity = [
      ...recentTransactions.map((t) => ({ type: 'payment', date: t.transactionDate, title: `Payment received for ${t.gig?.title || 'gig'}`, meta: t.client?.name || 'Client', amount: t.amount, status: t.status })),
      ...recentBookings.map((b) => ({ type: 'booking', date: b.createdAt, title: `Booking ${b.status}`, meta: `${b.gig?.title || 'Gig'} · ${b.client?.name || 'Client'}`, status: b.status })),
    ].sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 5);

    const yearStart = new Date(now.getFullYear(), 0, 1);
    const yearIncome = await Transaction.aggregate([{ $match: { freelancer, status: 'completed', transactionDate: { $gte: yearStart } } }, { $group: { _id: null, total: { $sum: '$amount' } } }]);
    const tax = estimateTax(yearIncome[0]?.total || 0);

    res.json({
      success: true,
      data: {
        summary: {
          totalIncome: totalIncomeAgg[0]?.total || 0,
          monthlyIncome: monthlyIncomeAgg[0]?.total || 0,
          pendingBookings,
          estimatedTax: tax.estimatedTax,
        },
        incomeTrend,
        recentActivity: activity,
        tax,
      },
    });
  } catch (err) {
    next(err);
  }
};

exports.listGigs = async (req, res, next) => {
  try {
    const gigs = await Gig.find({ freelancer: req.user._id }).sort({ createdAt: -1 });
    res.json({ success: true, data: gigs });
  } catch (err) { next(err); }
};

exports.getGig = async (req, res, next) => {
  try {
    if (!safeId(req.params.id)) return res.status(404).json({ success: false, message: 'Gig not found.' });
    const gig = await Gig.findOne({ _id: req.params.id, freelancer: req.user._id });
    if (!gig) return res.status(404).json({ success: false, message: 'Gig not found.' });
    res.json({ success: true, data: gig });
  } catch (err) { next(err); }
};

exports.createGig = async (req, res, next) => {
  try {
    const { title, description, category, price, deliveryTime } = req.body;
    if (!title || !description || !category || price === undefined || deliveryTime === undefined) {
      return res.status(400).json({ success: false, message: 'Title, description, category, price and delivery time are required.' });
    }
    if (Number(price) < 0 || Number(deliveryTime) < 1) return res.status(400).json({ success: false, message: 'Price and delivery time are invalid.' });
    const gig = await Gig.create({ freelancer: req.user._id, title, description, category, price: Number(price), deliveryTime: Number(deliveryTime) });
    res.status(201).json({ success: true, data: gig });
  } catch (err) { next(err); }
};

exports.updateGig = async (req, res, next) => {
  try {
    if (!safeId(req.params.id)) return res.status(404).json({ success: false, message: 'Gig not found.' });
    const allowed = ['title', 'description', 'category', 'price', 'deliveryTime', 'isActive'];
    const update = {};
    allowed.forEach((key) => { if (req.body[key] !== undefined) update[key] = req.body[key]; });
    if ('price' in update) update.price = Number(update.price);
    if ('deliveryTime' in update) update.deliveryTime = Number(update.deliveryTime);
    if ('price' in update && (Number.isNaN(update.price) || update.price < 0)) return res.status(400).json({ success: false, message: 'Price is invalid.' });
    if ('deliveryTime' in update && (!Number.isInteger(update.deliveryTime) || update.deliveryTime < 1)) return res.status(400).json({ success: false, message: 'Delivery time is invalid.' });
    const gig = await Gig.findOneAndUpdate({ _id: req.params.id, freelancer: req.user._id }, update, { new: true, runValidators: true });
    if (!gig) return res.status(404).json({ success: false, message: 'Gig not found.' });
    res.json({ success: true, data: gig });
  } catch (err) { next(err); }
};

exports.deleteGig = async (req, res, next) => {
  try {
    if (!safeId(req.params.id)) return res.status(404).json({ success: false, message: 'Gig not found.' });
    const gig = await Gig.findOne({ _id: req.params.id, freelancer: req.user._id });
    if (!gig) return res.status(404).json({ success: false, message: 'Gig not found.' });
    const hasHistory = await Booking.exists({ gig: gig._id });
    if (hasHistory) {
      gig.isActive = false;
      await gig.save();
      return res.json({ success: true, data: gig, archived: true, message: 'Gig archived because it has booking history.' });
    }
    await gig.deleteOne();
    res.json({ success: true, data: null, message: 'Gig deleted.' });
  } catch (err) { next(err); }
};

exports.listGigBookings = async (req, res, next) => {
  try {
    if (!safeId(req.params.id)) return res.status(404).json({ success: false, message: 'Gig not found.' });
    const exists = await Gig.exists({ _id: req.params.id, freelancer: req.user._id });
    if (!exists) return res.status(404).json({ success: false, message: 'Gig not found.' });
    const bookings = await Booking.find({ gig: req.params.id, freelancer: req.user._id }).sort({ createdAt: -1 }).populate('client', 'name email');
    res.json({ success: true, data: bookings });
  } catch (err) { next(err); }
};

exports.listBookings = async (req, res, next) => {
  try {
    const filter = { freelancer: req.user._id };
    const allowed = ['pending', 'accepted', 'declined', 'completed', 'cancelled'];
    if (req.query.status && allowed.includes(req.query.status)) filter.status = req.query.status;
    const bookings = await Booking.find(filter).sort({ createdAt: -1 }).populate('client', 'name email').populate('gig', 'title category price');
    res.json({ success: true, data: bookings });
  } catch (err) { next(err); }
};

async function updateBookingStatus(req, res, status) {
  if (!safeId(req.params.id)) return res.status(404).json({ success: false, message: 'Booking not found.' });
  const allowedFrom = status === 'accepted' || status === 'declined' ? 'pending' : 'accepted';
  const booking = await Booking.findOneAndUpdate(
    { _id: req.params.id, freelancer: req.user._id, status: allowedFrom },
    { status, ...(status === 'completed' ? { completedAt: new Date() } : {}) },
    { new: true }
  ).populate('client', 'name email').populate('gig', 'title category price');
  if (!booking) return res.status(409).json({ success: false, message: `Booking cannot be changed to ${status}.` });
  return res.json({ success: true, data: booking });
}

exports.acceptBooking = async (req, res, next) => { try { return await updateBookingStatus(req, res, 'accepted'); } catch (err) { return next(err); } };
exports.declineBooking = async (req, res, next) => { try { return await updateBookingStatus(req, res, 'declined'); } catch (err) { return next(err); } };
exports.completeBooking = async (req, res, next) => {
  try {
    const result = await completeBooking({ bookingId: req.params.id, freelancerId: req.user._id });
    const booking = await Booking.findById(result.booking._id).populate('client', 'name email').populate('gig', 'title category price');
    res.json({ success: true, data: { booking, transaction: result.transaction } });
  } catch (err) { next(err); }
};

exports.transactions = async (req, res, next) => {
  try {
    const filter = { freelancer: req.user._id };
    const range = dateRange(req.query.startDate, req.query.endDate);
    if (Object.keys(range).length) filter.transactionDate = range;
    const transactions = await Transaction.find(filter).sort({ transactionDate: -1 }).populate('client', 'name').populate('gig', 'title');
    res.json({ success: true, data: transactions });
  } catch (err) { next(err); }
};

exports.incomeSummary = async (req, res, next) => {
  try {
    const filter = { freelancer: req.user._id, status: 'completed' };
    const range = dateRange(req.query.startDate, req.query.endDate);
    if (Object.keys(range).length) filter.transactionDate = range;
    const [category, total] = await Promise.all([
      Transaction.aggregate([{ $match: filter }, { $group: { _id: '$category', income: { $sum: '$amount' } } }, { $sort: { income: -1 } }]),
      Transaction.aggregate([{ $match: filter }, { $group: { _id: null, income: { $sum: '$amount' } } }]),
    ]);
    const tax = estimateTax(total[0]?.income || 0);
    res.json({ success: true, data: { totalIncome: total[0]?.income || 0, byCategory: category.map((x) => ({ category: x._id, income: Number(x.income.toFixed(2)) })), tax } });
  } catch (err) { next(err); }
};

exports.exportTransactions = async (req, res, next) => {
  try {
    const filter = { freelancer: req.user._id };
    const range = dateRange(req.query.startDate, req.query.endDate);
    if (Object.keys(range).length) filter.transactionDate = range;
    const transactions = await Transaction.find(filter).sort({ transactionDate: -1 }).populate('client', 'name').populate('gig', 'title');
    const escape = (value) => `"${String(value ?? '').replace(/"/g, '""')}"`;
    const rows = [
      ['Transaction Date', 'Client', 'Gig', 'Category', 'Amount', 'Status', 'Booking ID'],
      ...transactions.map((t) => [new Date(t.transactionDate).toISOString(), t.client?.name, t.gig?.title, t.category, t.amount, t.status, t.booking]),
    ];
    const csv = rows.map((row) => row.map(escape).join(',')).join('\n');
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="hustlehub-transactions-${new Date().toISOString().slice(0, 10)}.csv"`);
    res.send(csv);
  } catch (err) { next(err); }
};

exports.profile = async (req, res, next) => {
  try {
    const user = await User.findById(req.user._id).select('-password');
    res.json({ success: true, data: user });
  } catch (err) { next(err); }
};

exports.updateProfile = async (req, res, next) => {
  try {
    const allowed = ['name', 'bio', 'skills', 'hourlyRate', 'portfolioLinks'];
    const update = {};
    allowed.forEach((key) => { if (req.body[key] !== undefined) update[key] = req.body[key]; });
    if ('hourlyRate' in update) {
      update.hourlyRate = Number(update.hourlyRate);
      if (Number.isNaN(update.hourlyRate) || update.hourlyRate < 0) return res.status(400).json({ success: false, message: 'Hourly rate is invalid.' });
    }
    if ('skills' in update && !Array.isArray(update.skills)) return res.status(400).json({ success: false, message: 'Skills must be an array.' });
    if ('portfolioLinks' in update && !Array.isArray(update.portfolioLinks)) return res.status(400).json({ success: false, message: 'Portfolio links must be an array.' });
    const user = await User.findByIdAndUpdate(req.user._id, update, { new: true, runValidators: true }).select('-password');
    res.json({ success: true, data: user });
  } catch (err) { next(err); }
};

exports.changePassword = async (req, res, next) => {
  try {
    const { currentPassword, newPassword, confirmPassword } = req.body;
    if (!currentPassword || !newPassword || !confirmPassword) return res.status(400).json({ success: false, message: 'All password fields are required.' });
    if (newPassword !== confirmPassword) return res.status(400).json({ success: false, message: 'New passwords do not match.' });
    if (newPassword.length < 8) return res.status(400).json({ success: false, message: 'New password must be at least 8 characters.' });
    const user = await User.findById(req.user._id);
    if (!user || !(await user.matchPassword(currentPassword))) return res.status(401).json({ success: false, message: 'Current password is incorrect.' });
    user.password = newPassword;
    await user.save();
    res.json({ success: true, message: 'Password changed successfully.' });
  } catch (err) { next(err); }
};
