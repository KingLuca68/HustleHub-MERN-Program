const mongoose = require('mongoose');

const TransactionSchema = new mongoose.Schema(
  {
    booking: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Booking',
      required: true,
      unique: true,
      index: true,
    },
    freelancer: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    client: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    gig: { type: mongoose.Schema.Types.ObjectId, ref: 'Gig', required: true },
    category: { type: String, required: true, trim: true },
    amount: { type: Number, required: true, min: 0 },
    status: {
      type: String,
      enum: ['pending', 'completed', 'cancelled'],
      default: 'completed',
    },
    transactionDate: { type: Date, default: Date.now, index: true },
  },
  { timestamps: true }
);

TransactionSchema.index({ freelancer: 1, transactionDate: -1 });
TransactionSchema.index({ freelancer: 1, category: 1 });

module.exports = mongoose.model('Transaction', TransactionSchema);
