const mongoose = require('mongoose');

const BookingSchema = new mongoose.Schema(
  {
    gig: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Gig',
      required: true,
      index: true,
    },
    freelancer: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    client: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    requestedDate: { type: Date, required: true },
    amount: { type: Number, required: true, min: 0 },
    status: {
      type: String,
      enum: ['pending', 'accepted', 'declined', 'completed', 'cancelled'],
      default: 'pending',
      index: true,
    },
    completedAt: { type: Date, default: null },
  },
  { timestamps: true }
);

BookingSchema.index({ freelancer: 1, status: 1, createdAt: -1 });
BookingSchema.index({ freelancer: 1, requestedDate: 1 });

module.exports = mongoose.model('Booking', BookingSchema);
