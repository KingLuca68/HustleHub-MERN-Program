import { Link } from 'react-router-dom';
import { LogoIcon } from '../Icons';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const handleHowItWorksClick = (e) => {
    const el = document.getElementById('how-it-works');
    if (el) {
      e.preventDefault();
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="public-footer">
      <div className="footer-container">
        <div className="footer-top">
          {/* Brand Info */}
          <div className="footer-brand">
            <Link to="/" className="brand-logo" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
              <LogoIcon size={28} />
              <span className="brand-name">
                HustleHub<span className="brand-plus">+</span>
              </span>
            </Link>
            <p className="footer-tagline">
              Freelance work, done securely. Empowering clients and freelancers with trust, automated tracking, and protected workflows.
            </p>
          </div>

          {/* Quick Links */}
          <div className="footer-nav-col">
            <h4 className="footer-col-title">Navigation</h4>
            <ul className="footer-links">
              <li>
                <a href="#how-it-works" onClick={handleHowItWorksClick}>
                  How It Works
                </a>
              </li>
              <li>
                <Link to="/gigs">Browse Gigs</Link>
              </li>
              <li>
                <Link to="/login">Log In</Link>
              </li>
              <li>
                <Link to="/register">Register</Link>
              </li>
            </ul>
          </div>

          {/* Direct Portals */}
          <div className="footer-nav-col">
            <h4 className="footer-col-title">Portals</h4>
            <ul className="footer-links">
              <li>
                <Link to="/register?role=client">Client Sign Up</Link>
              </li>
              <li>
                <Link to="/register?role=freelancer">Freelancer Sign Up</Link>
              </li>
              <li>
                <Link to="/login">Account Sign In</Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Footer Bottom Bar */}
        <div className="footer-bottom">
          <p className="footer-copyright">
            &copy; {currentYear} HustleHub+. All rights reserved. Secure MERN architecture.
          </p>
          <div className="footer-security-pill">
            <span className="security-indicator" />
            <span>End-to-End JWT Guarded</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
