import { Link } from 'react-router-dom';
import { ArrowRightIcon, ShieldCheckIcon, ChartIcon, SparklesIcon, CheckCircleIcon, DollarSignIcon } from '../Icons';

const HeroSection = () => {
  return (
    <section className="hero-section">
      <div className="hero-glow-bg hero-glow-1" />
      <div className="hero-glow-bg hero-glow-2" />

      <div className="hero-container">
        {/* Left / Top Hero Content */}
        <div className="hero-content">
          <div className="hero-badge">
            <SparklesIcon size={14} className="hero-badge-icon" />
            <span>Next-Gen Secure Freelance Marketplace</span>
          </div>

          <h1 className="hero-headline">
            Freelance work, <span className="gradient-text">done securely.</span>
          </h1>

          <p className="hero-subheadline">
            HustleHub+ connects clients with skilled freelancers — with secure accounts, simple bookings, and automatic income tracking for every freelancer.
          </p>

          <div className="hero-ctas">
            <Link to="/register" className="btn-hero-primary">
              <span>Get Started</span>
              <ArrowRightIcon size={18} />
            </Link>
            <Link to="/gigs" className="btn-hero-secondary">
              <span>Browse Gigs</span>
            </Link>
          </div>

          <div className="hero-trust-metrics">
            <div className="metric-item">
              <span className="metric-dot" />
              <span>Role-Based Access</span>
            </div>
            <div className="metric-item">
              <span className="metric-dot" />
              <span>Protected APIs</span>
            </div>
            <div className="metric-item">
              <span className="metric-dot" />
              <span>Instant Setup</span>
            </div>
          </div>
        </div>

        {/* Right / Angled Dashboard Preview */}
        <div className="hero-preview-wrapper">
          <div className="dashboard-preview-card">
            {/* Top Bar of Mockup */}
            <div className="mockup-header">
              <div className="mockup-dots">
                <span className="dot dot-red" />
                <span className="dot dot-yellow" />
                <span className="dot dot-green" />
              </div>
              <div className="mockup-title-bar">
                <ShieldCheckIcon size={14} className="text-emerald-400" />
                <span>freelancer.hustlehub.app / dashboard</span>
              </div>
              <div className="mockup-role-pill">Freelancer Mode</div>
            </div>

            {/* Mockup Body */}
            <div className="mockup-body">
              {/* Profile Bar */}
              <div className="mockup-user-bar">
                <div className="mockup-avatar">SN</div>
                <div>
                  <div className="mockup-user-name">Sipho Ndlovu</div>
                  <div className="mockup-user-sub">Full-Stack MERN Developer</div>
                </div>
                <div className="mockup-verified-badge">
                  <CheckCircleIcon size={12} />
                  <span>Verified</span>
                </div>
              </div>

              {/* Stats Cards */}
              <div className="mockup-stats-grid">
                <div className="mockup-stat-card highlight">
                  <div className="mockup-stat-label">
                    <DollarSignIcon size={14} />
                    <span>Monthly Income</span>
                  </div>
                  <div className="mockup-stat-value">R18,450.00</div>
                  <div className="mockup-stat-trend">+24.5% vs last month</div>
                </div>

                <div className="mockup-stat-card">
                  <div className="mockup-stat-label">
                    <ChartIcon size={14} />
                    <span>Est. Tax Provision</span>
                  </div>
                  <div className="mockup-stat-value">R3,320.00</div>
                  <div className="mockup-stat-sub">Auto-calculated 18%</div>
                </div>
              </div>

              {/* Active Bookings Mini Strip */}
              <div className="mockup-active-project">
                <div className="mockup-project-info">
                  <div className="mockup-project-status-dot" />
                  <div>
                    <div className="mockup-project-title">E-Commerce REST API Engine</div>
                    <div className="mockup-project-client">Client: Apex Retail Ltd &bull; Due in 2 days</div>
                  </div>
                </div>
                <div className="mockup-project-price">R3,200</div>
              </div>
            </div>

            {/* Floating Accent Badges */}
            <div className="floating-badge floating-badge-top">
              <ShieldCheckIcon size={16} />
              <span>JWT + bcrypt Guarded</span>
            </div>

            <div className="floating-badge floating-badge-bottom">
              <ChartIcon size={16} />
              <span>Real-time Financials</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
