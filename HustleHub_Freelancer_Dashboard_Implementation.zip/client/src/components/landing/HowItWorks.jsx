import { 
  SearchIcon, 
  CalendarIcon, 
  CheckCircleIcon, 
  PlusCircleIcon, 
  UserCheckIcon, 
  ChartIcon,
  UserIcon,
  BriefcaseIcon 
} from '../Icons';

const clientSteps = [
  {
    step: '1',
    title: 'Discover',
    description: 'Search and compare freelancers by skill, category, and price.',
    icon: SearchIcon,
  },
  {
    step: '2',
    title: 'Book',
    description: 'Choose a gig, confirm the details, and book in a few clicks.',
    icon: CalendarIcon,
  },
  {
    step: '3',
    title: 'Get It Done',
    description: 'Track progress and payment from one dashboard.',
    icon: CheckCircleIcon,
  },
];

const freelancerSteps = [
  {
    step: '1',
    title: 'List Your Gig',
    description: 'Set your pricing, delivery time, and description.',
    icon: PlusCircleIcon,
  },
  {
    step: '2',
    title: 'Get Booked',
    description: 'Accept booking requests from clients.',
    icon: UserCheckIcon,
  },
  {
    step: '3',
    title: 'Track & Earn',
    description: 'Watch your income grow, with tax estimates built in.',
    icon: ChartIcon,
  },
];

const HowItWorks = () => {
  return (
    <section id="how-it-works" className="how-it-works-section">
      <div className="section-container">
        <div className="section-header text-center">
          <div className="section-tag">Simple & Transparent</div>
          <h2 className="section-title">How HustleHub+ Works</h2>
          <p className="section-subtitle">
            Whether you are commissioning software or delivering client solutions, HustleHub+ makes the entire journey frictionless.
          </p>
        </div>

        <div className="how-it-works-grid">
          {/* Column 1: For Clients */}
          <div className="role-workflow-card client-workflow">
            <div className="workflow-header">
              <div className="workflow-badge client-badge">
                <UserIcon size={16} />
                <span>For Clients</span>
              </div>
              <h3 className="workflow-title">Hire talent with total confidence</h3>
            </div>

            <div className="workflow-steps">
              {clientSteps.map((item, idx) => {
                const Icon = item.icon;
                return (
                  <div key={idx} className="step-item">
                    <div className="step-badge-wrapper">
                      <span className="step-number">{item.step}</span>
                      {idx < clientSteps.length - 1 && <span className="step-line" />}
                    </div>
                    <div className="step-content">
                      <div className="step-title-row">
                        <div className="step-icon-box">
                          <Icon size={16} />
                        </div>
                        <h4 className="step-title">{item.title}</h4>
                      </div>
                      <p className="step-desc">{item.description}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Column 2: For Freelancers */}
          <div className="role-workflow-card freelancer-workflow">
            <div className="workflow-header">
              <div className="workflow-badge freelancer-badge">
                <BriefcaseIcon size={16} />
                <span>For Freelancers</span>
              </div>
              <h3 className="workflow-title">Monetize your craft seamlessly</h3>
            </div>

            <div className="workflow-steps">
              {freelancerSteps.map((item, idx) => {
                const Icon = item.icon;
                return (
                  <div key={idx} className="step-item">
                    <div className="step-badge-wrapper">
                      <span className="step-number">{item.step}</span>
                      {idx < freelancerSteps.length - 1 && <span className="step-line" />}
                    </div>
                    <div className="step-content">
                      <div className="step-title-row">
                        <div className="step-icon-box">
                          <Icon size={16} />
                        </div>
                        <h4 className="step-title">{item.title}</h4>
                      </div>
                      <p className="step-desc">{item.description}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
