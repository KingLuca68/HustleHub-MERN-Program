import { Link } from 'react-router-dom';
import { UserIcon, BriefcaseIcon, ArrowRightIcon } from '../Icons';

const SignUpBanner = () => {
  return (
    <section className="cta-banner-section">
      <div className="section-container">
        <div className="cta-banner-card">
          {/* Ambient Glows */}
          <div className="cta-glow cta-glow-left" />
          <div className="cta-glow cta-glow-right" />

          <div className="cta-banner-content">
            <h2 className="cta-banner-title">Ready to get started?</h2>
            <p className="cta-banner-subtitle">
              Join as a client to find talent, or as a freelancer to start earning.
            </p>

            <div className="cta-banner-buttons">
              <Link to="/register?role=client" className="btn-cta-client">
                <UserIcon size={18} />
                <span>Sign Up as a Client</span>
                <ArrowRightIcon size={16} />
              </Link>

              <Link to="/register?role=freelancer" className="btn-cta-freelancer">
                <BriefcaseIcon size={18} />
                <span>Sign Up as a Freelancer</span>
                <ArrowRightIcon size={16} />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SignUpBanner;
