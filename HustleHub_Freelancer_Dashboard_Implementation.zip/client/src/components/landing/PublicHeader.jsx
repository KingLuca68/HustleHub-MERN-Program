import { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { LogoIcon, MenuIcon, XIcon, ArrowRightIcon } from '../Icons';

const PublicHeader = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const handleHowItWorksClick = (e) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    if (location.pathname !== '/') {
      navigate('/#how-it-works');
    } else {
      const el = document.getElementById('how-it-works');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  return (
    <header className="public-header">
      <div className="header-container">
        {/* Brand Logo */}
        <Link to="/" className="brand-logo" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
          <LogoIcon size={32} />
          <span className="brand-name">
            HustleHub<span className="brand-plus">+</span>
          </span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="desktop-nav">
          <a href="#how-it-works" onClick={handleHowItWorksClick} className="nav-link">
            How It Works
          </a>
          <Link to="/gigs" className="nav-link">
            Browse Gigs
          </Link>
        </nav>

        {/* Right CTA Actions */}
        <div className="header-actions">
          <Link to="/login" className="btn-ghost">
            Log In
          </Link>
          <Link to="/register" className="btn-header-primary">
            <span>Get Started</span>
            <ArrowRightIcon size={16} />
          </Link>
        </div>

        {/* Mobile Hamburger Toggle */}
        <button
          type="button"
          className="mobile-menu-btn"
          onClick={() => setMobileMenuOpen((prev) => !prev)}
          aria-label={mobileMenuOpen ? 'Close Menu' : 'Open Menu'}
        >
          {mobileMenuOpen ? <XIcon size={24} /> : <MenuIcon size={24} />}
        </button>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="mobile-nav-drawer">
          <nav className="mobile-nav-links">
            <a href="#how-it-works" onClick={handleHowItWorksClick} className="mobile-nav-link">
              How It Works
            </a>
            <Link
              to="/gigs"
              className="mobile-nav-link"
              onClick={() => setMobileMenuOpen(false)}
            >
              Browse Gigs
            </Link>
          </nav>
          <div className="mobile-actions">
            <Link
              to="/login"
              className="btn-ghost-mobile"
              onClick={() => setMobileMenuOpen(false)}
            >
              Log In
            </Link>
            <Link
              to="/register"
              className="btn-primary-mobile"
              onClick={() => setMobileMenuOpen(false)}
            >
              <span>Get Started</span>
              <ArrowRightIcon size={16} />
            </Link>
          </div>
        </div>
      )}
    </header>
  );
};

export default PublicHeader;
