import { Link } from 'react-router-dom';
import { ClockIcon, TagIcon, ArrowRightIcon } from '../Icons';

const GigCard = ({ gig }) => {
  const {
    id,
    title,
    category,
    price,
    deliveryTime,
    freelancer: { name, avatar, roleTitle, initials },
    accentColor = '#6366f1'
  } = gig;

  return (
    <div className="gig-card">
      <div className="gig-card-top">
        {/* Category Pill */}
        <div className="gig-category-pill">
          <TagIcon size={12} />
          <span>{category}</span>
        </div>
        <span className="gig-delivery-badge">
          <ClockIcon size={12} />
          <span>{deliveryTime}</span>
        </span>
      </div>

      {/* Gig Title */}
      <h3 className="gig-card-title">{title}</h3>

      {/* Freelancer Profile */}
      <div className="gig-freelancer-row">
        <div 
          className="gig-avatar" 
          style={{ 
            background: avatar ? `url(${avatar}) center/cover` : `linear-gradient(135deg, ${accentColor}, #4338ca)` 
          }}
        >
          {!avatar && initials}
        </div>
        <div className="gig-freelancer-details">
          <div className="gig-freelancer-name">{name}</div>
          <div className="gig-freelancer-role">{roleTitle}</div>
        </div>
      </div>

      {/* Footer Row: Price and View Gig CTA */}
      <div className="gig-card-footer">
        <div className="gig-price-box">
          <span className="gig-price-label">Starting from</span>
          <span className="gig-price-value">R{price}</span>
        </div>

        <Link to={`/gigs?highlight=${id}`} className="btn-view-gig">
          <span>View Gig</span>
          <ArrowRightIcon size={14} />
        </Link>
      </div>
    </div>
  );
};

export default GigCard;
