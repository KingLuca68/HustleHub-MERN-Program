import { Link } from 'react-router-dom';
import GigCard from './GigCard';
import { ArrowRightIcon, SparklesIcon } from '../Icons';

export const sampleGigs = [
  {
    id: 'gig-1',
    title: 'Full-Stack MERN Development',
    category: 'Web & Full Stack',
    price: 850,
    deliveryTime: '5-day delivery',
    accentColor: '#6366f1',
    freelancer: {
      name: 'Sipho Ndlovu',
      roleTitle: 'Full Stack Engineer',
      initials: 'SN',
    },
  },
  {
    id: 'gig-2',
    title: 'React Website Development',
    category: 'Frontend & UI',
    price: 650,
    deliveryTime: '3-day delivery',
    accentColor: '#38bdf8',
    freelancer: {
      name: 'Anika Patel',
      roleTitle: 'React Specialist',
      initials: 'AP',
    },
  },
  {
    id: 'gig-3',
    title: 'REST API Integration',
    category: 'Backend & APIs',
    price: 500,
    deliveryTime: '2-day delivery',
    accentColor: '#10b981',
    freelancer: {
      name: 'Liam Davies',
      roleTitle: 'Node.js & Security Architect',
      initials: 'LD',
    },
  },
  {
    id: 'gig-4',
    title: 'UI/UX Design for Web Apps',
    category: 'UI/UX Design',
    price: 400,
    deliveryTime: '3-day delivery',
    accentColor: '#f59e0b',
    freelancer: {
      name: 'Thabo Molefe',
      roleTitle: 'Product & UI Designer',
      initials: 'TM',
    },
  },
];

const FeaturedGigs = () => {
  return (
    <section className="featured-gigs-section">
      <div className="section-container">
        <div className="section-header text-center">
          <div className="section-tag">
            <SparklesIcon size={13} />
            <span>Top Picks</span>
          </div>
          <h2 className="section-title">Explore What&apos;s on HustleHub+</h2>
          <p className="section-subtitle">
            Browse high-impact technical and creative gigs offered by verified freelancers ready to start immediately.
          </p>
        </div>

        {/* Grid of 4 Cards */}
        <div className="gigs-grid">
          {sampleGigs.map((gig) => (
            <GigCard key={gig.id} gig={gig} />
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="featured-gigs-cta-wrapper">
          <Link to="/gigs" className="btn-browse-all">
            <span>Browse All Gigs</span>
            <ArrowRightIcon size={18} />
          </Link>
        </div>
      </div>
    </section>
  );
};

export default FeaturedGigs;
