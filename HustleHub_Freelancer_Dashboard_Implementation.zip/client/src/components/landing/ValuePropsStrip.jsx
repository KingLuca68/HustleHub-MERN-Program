import { LockIcon, ShieldCheckIcon, ChartIcon, HandshakeIcon } from '../Icons';

const valueProps = [
  {
    icon: LockIcon,
    title: 'Secure, role-based accounts',
    description: 'Distinct workspaces and permissions for clients, freelancers, and admins.',
    accent: 'blue',
  },
  {
    icon: ShieldCheckIcon,
    title: 'Every input validated, every route protected',
    description: 'Zero unauthorized access with JWT token defense and strict schema guards.',
    accent: 'emerald',
  },
  {
    icon: ChartIcon,
    title: 'Automatic income & tax estimates for freelancers',
    description: 'Keep your earnings transparent with built-in financial breakdown calculators.',
    accent: 'purple',
  },
  {
    icon: HandshakeIcon,
    title: 'One platform for clients and freelancers',
    description: 'Unified ecosystem connecting high-demand tech talent with forward-thinking businesses.',
    accent: 'amber',
  },
];

const ValuePropsStrip = () => {
  return (
    <section className="value-props-section">
      <div className="value-props-container">
        <div className="value-props-grid">
          {valueProps.map((item, index) => {
            const Icon = item.icon;
            return (
              <div key={index} className={`value-prop-card accent-${item.accent}`}>
                <div className="value-prop-icon-wrapper">
                  <Icon size={22} className="value-prop-icon" />
                </div>
                <div className="value-prop-content">
                  <h3 className="value-prop-title">{item.title}</h3>
                  <p className="value-prop-desc">{item.description}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default ValuePropsStrip;
