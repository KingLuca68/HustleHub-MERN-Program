import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const navItems = [
  { to: '/freelancer', label: 'Overview', icon: '⌂', end: true },
  { to: '/freelancer/gigs', label: 'My Gigs', icon: '▦' },
  { to: '/freelancer/bookings', label: 'Bookings', icon: '◫' },
  { to: '/freelancer/income', label: 'Income & Tax', icon: '◈' },
  { to: '/freelancer/profile', label: 'Profile', icon: '◉' },
];

export default function FreelancerLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const title = navItems.find((item) => item.end ? location.pathname === item.to : location.pathname.startsWith(item.to))?.label || 'Freelancer Dashboard';

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="freelancer-shell">
      <aside className="freelancer-sidebar">
        <div className="freelancer-brand">
          <div className="freelancer-brand-mark">H+</div>
          <div>
            <strong>HustleHub<span>+</span></strong>
            <small>Freelancer workspace</small>
          </div>
        </div>

        <nav className="freelancer-nav" aria-label="Freelancer navigation">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) => `freelancer-nav-link ${isActive ? 'active' : ''}`}
            >
              <span className="nav-symbol">{item.icon}</span>
              <span>{item.label}</span>
            </NavLink>
          ))}
        </nav>

        <div className="freelancer-sidebar-footer">
          <div className="mini-user">
            <div className="avatar">{user?.name?.charAt(0)?.toUpperCase() || 'F'}</div>
            <div className="mini-user-copy">
              <strong>{user?.name || 'Freelancer'}</strong>
              <span>{user?.email || ''}</span>
            </div>
          </div>
          <button className="sidebar-logout" onClick={handleLogout}>Sign out</button>
        </div>
      </aside>

      <div className="freelancer-main">
        <header className="freelancer-topbar">
          <div>
            <div className="eyebrow">Freelancer portal</div>
            <h1>{title}</h1>
          </div>
          <div className="topbar-actions">
            <span className="live-chip"><span className="live-dot" /> Account active</span>
            <NavLink to="/gigs" className="browse-link">Browse work</NavLink>
          </div>
        </header>
        <main className="freelancer-content"><Outlet /></main>
      </div>
    </div>
  );
}
