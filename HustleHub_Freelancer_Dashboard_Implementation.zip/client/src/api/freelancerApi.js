import API from './axios';

const freelancerApi = {
  getDashboard: () => API.get('/freelancer/dashboard'),
  getGigs: () => API.get('/freelancer/gigs'),
  getGig: (id) => API.get(`/freelancer/gigs/${id}`),
  createGig: (payload) => API.post('/freelancer/gigs', payload),
  updateGig: (id, payload) => API.put(`/freelancer/gigs/${id}`, payload),
  deleteGig: (id) => API.delete(`/freelancer/gigs/${id}`),
  getGigBookings: (id) => API.get(`/freelancer/gigs/${id}/bookings`),
  getBookings: (status = '') => API.get('/freelancer/bookings', { params: status ? { status } : {} }),
  acceptBooking: (id) => API.patch(`/freelancer/bookings/${id}/accept`),
  declineBooking: (id) => API.patch(`/freelancer/bookings/${id}/decline`),
  completeBooking: (id) => API.patch(`/freelancer/bookings/${id}/complete`),
  getTransactions: (params = {}) => API.get('/freelancer/transactions', { params }),
  getIncomeSummary: (params = {}) => API.get('/freelancer/income/summary', { params }),
  getProfile: () => API.get('/freelancer/profile'),
  updateProfile: (payload) => API.patch('/freelancer/profile', payload),
  changePassword: (payload) => API.patch('/freelancer/profile/password', payload),
};

export default freelancerApi;
