import { useState } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import PublicHeader from '../components/landing/PublicHeader';
import Footer from '../components/landing/Footer';
import GigCard from '../components/landing/GigCard';
import { sampleGigs } from '../components/landing/FeaturedGigs';
import { SearchIcon, SparklesIcon, ArrowRightIcon } from '../components/Icons';

const allCategories = ['All Categories', 'Web & Full Stack', 'Frontend & UI', 'Backend & APIs', 'UI/UX Design'];

const BrowseGigs = () => {
  const [searchParams] = useSearchParams();
  const highlightId = searchParams.get('highlight');

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All Categories');

  const filteredGigs = sampleGigs.filter((gig) => {
    const matchesCategory =
      selectedCategory === 'All Categories' || gig.category === selectedCategory;
    const matchesSearch =
      gig.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      gig.freelancer.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      gig.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="landing-page-root">
      <PublicHeader />

      <main className="browse-gigs-page">
        <div className="section-container">
          {/* Header */}
          <div className="browse-header text-center">
            <div className="section-tag">
              <SparklesIcon size={14} />
              <span>Marketplace</span>
            </div>
            <h1 className="section-title">Browse Top Freelance Gigs</h1>
            <p className="section-subtitle">
              Discover verified technical and creative services. Book directly or create your freelancer profile today.
            </p>
          </div>

          {/* Search & Filter Controls */}
          <div className="browse-controls">
            <div className="search-bar-wrapper">
              <SearchIcon size={18} className="search-bar-icon" />
              <input
                type="text"
                placeholder="Search gigs by skill, title, or freelancer..."
                className="search-input"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            <div className="category-filter-chips">
              {allCategories.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  className={`filter-chip ${selectedCategory === cat ? 'active' : ''}`}
                  onClick={() => setSelectedCategory(cat)}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Gigs List */}
          {filteredGigs.length > 0 ? (
            <div className="gigs-grid">
              {filteredGigs.map((gig) => (
                <div key={gig.id} className={highlightId === gig.id ? 'highlighted-gig-wrapper' : ''}>
                  <GigCard gig={gig} />
                </div>
              ))}
            </div>
          ) : (
            <div className="empty-gigs-box">
              <h3>No gigs found</h3>
              <p>Try adjusting your search terms or selecting a different category.</p>
              <button
                type="button"
                className="btn-reset-filters"
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory('All Categories');
                }}
              >
                Reset Filters
              </button>
            </div>
          )}

          {/* Call to action for visitors */}
          <div className="browse-cta-box">
            <div>
              <h3>Looking to offer your own services?</h3>
              <p>Create a freelancer profile in minutes and start receiving client requests.</p>
            </div>
            <Link to="/register?role=freelancer" className="btn-browse-cta">
              <span>List Your Services</span>
              <ArrowRightIcon size={16} />
            </Link>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default BrowseGigs;
