import { useAuth } from '../context/AuthContext';

const ClientDashboard = () => {
  const { user } = useAuth();

  return (
    <div className="role-dashboard">
      <div className="dashboard-header-card">
        <h2>Client Portal</h2>
        <p>Welcome back, {user?.name}. Manage your projects and hires.</p>
        <span className="role-badge client">Client</span>
      </div>
      
      <div className="dashboard-grid">
        <div className="dashboard-card">
          <h3>My Projects</h3>
          <p>Active Projects: 2</p>
          <p>Pending Proposals: 5</p>
          <button className="btn-secondary">Post New Project</button>
        </div>
        <div className="dashboard-card">
          <h3>Recent Invoices</h3>
          <p>Invoice #1024 - Paid</p>
          <p>Invoice #1025 - Pending</p>
        </div>
      </div>
    </div>
  );
};

export default ClientDashboard;
