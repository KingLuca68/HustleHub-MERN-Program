import { useAuth } from '../context/AuthContext';

const AdminDashboard = () => {
  const { user } = useAuth();

  return (
    <div className="role-dashboard">
      <div className="dashboard-header-card">
        <h2>Admin Portal</h2>
        <p>Welcome back, {user?.name}. You have full system access.</p>
        <span className="role-badge admin">Administrator</span>
      </div>
      
      <div className="dashboard-grid">
        <div className="dashboard-card">
          <h3>System Statistics</h3>
          <p>Total Users: 142</p>
          <p>Active Sessions: 12</p>
        </div>
        <div className="dashboard-card">
          <h3>Recent Activity</h3>
          <p>User "john_doe" registered</p>
          <p>System backup completed</p>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
