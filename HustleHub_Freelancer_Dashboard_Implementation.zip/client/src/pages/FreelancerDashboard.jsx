import { Navigate, Route, Routes } from 'react-router-dom';
import FreelancerLayout from '../components/FreelancerLayout';
import Overview from './freelancer/Overview';
import Gigs from './freelancer/Gigs';
import GigDetails from './freelancer/GigDetails';
import Bookings from './freelancer/Bookings';
import Income from './freelancer/Income';
import Profile from './freelancer/Profile';

export default function FreelancerDashboard() {
  return (
    <Routes>
      <Route element={<FreelancerLayout />}>
        <Route index element={<Overview />} />
        <Route path="gigs" element={<Gigs />} />
        <Route path="gigs/:id" element={<GigDetails />} />
        <Route path="bookings" element={<Bookings />} />
        <Route path="income" element={<Income />} />
        <Route path="profile" element={<Profile />} />
        <Route path="*" element={<Navigate to="/freelancer" replace />} />
      </Route>
    </Routes>
  );
}
