import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import PublicHeader from '../components/landing/PublicHeader';
import HeroSection from '../components/landing/HeroSection';
import ValuePropsStrip from '../components/landing/ValuePropsStrip';
import HowItWorks from '../components/landing/HowItWorks';
import FeaturedGigs from '../components/landing/FeaturedGigs';
import SignUpBanner from '../components/landing/SignUpBanner';
import Footer from '../components/landing/Footer';

const LandingPage = () => {
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  // Redirect already-authenticated users directly to their dashboard
  useEffect(() => {
    if (!loading && user) {
      navigate('/dashboard', { replace: true });
    }
  }, [user, loading, navigate]);

  if (loading) {
    return (
      <div className="landing-loading">
        <div className="spinner" />
      </div>
    );
  }

  // If user is logged in, useEffect will redirect; return null during redirection
  if (user) {
    return null;
  }

  return (
    <div className="landing-page-root">
      <PublicHeader />
      <main>
        <HeroSection />
        <ValuePropsStrip />
        <HowItWorks />
        <FeaturedGigs />
        <SignUpBanner />
      </main>
      <Footer />
    </div>
  );
};

export default LandingPage;
