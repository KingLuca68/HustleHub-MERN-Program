import { useEffect, useMemo, useState } from 'react';
import freelancerApi from '../../api/freelancerApi';

const money = (value) => `R ${Number(value || 0).toLocaleString('en-ZA', { minimumFractionDigits: 2 })}`;
const fmt = (value) => new Date(value).toLocaleDateString('en-ZA', { day: '2-digit', month: 'short', year: 'numeric' });

export default function Income() {
  const [filters, setFilters] = useState({ startDate: '', endDate: '' });
  const [transactions, setTransactions] = useState([]);
  const [summary, setSummary] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  const load = () => { setLoading(true); Promise.all([freelancerApi.getTransactions(filters), freelancerApi.getIncomeSummary(filters)]).then(([t, s]) => { setTransactions(t.data.data); setSummary(s.data.data); }).catch((e) => setError(e.response?.data?.message || 'Unable to load income data.')).finally(() => setLoading(false)); };
  useEffect(load, []);

  const apply = (e) => { e?.preventDefault(); load(); };
  const exportCsv = async () => { try { const response = await freelancerApi.getTransactions(filters); const rows = [['Transaction Date','Client','Gig','Category','Amount','Status','Booking ID'], ...response.data.data.map((t) => [new Date(t.transactionDate).toISOString(), t.client?.name || '', t.gig?.title || '', t.category, t.amount, t.status, t.booking])]; const csv = rows.map((r) => r.map((v) => `"${String(v ?? '').replace(/"/g, '""')}"`).join(',')).join('\n'); const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' })); const a = document.createElement('a'); a.href = url; a.download = `hustlehub-transactions-${new Date().toISOString().slice(0,10)}.csv`; a.click(); URL.revokeObjectURL(url); } catch (e) { setError(e.response?.data?.message || 'Unable to export transactions.'); } };

  const maxCat = useMemo(() => Math.max(...(summary?.byCategory || []).map((c) => c.income), 1), [summary]);

  return <div className="dashboard-stack">
    <div className="page-intro"><div><span className="section-kicker">Financial centre</span><h2>Income & Tax</h2><p>Use completed transactions to understand your income and view a demonstration tax estimate.</p></div><button className="secondary-btn export-btn" onClick={exportCsv}>↓ Export CSV</button></div>
    <section className="panel-card filter-panel"><form onSubmit={apply} className="filter-row"><label>From<input type="date" value={filters.startDate} onChange={(e) => setFilters({ ...filters, startDate: e.target.value })} /></label><label>To<input type="date" value={filters.endDate} onChange={(e) => setFilters({ ...filters, endDate: e.target.value })} /></label><button className="primary-btn" type="submit">Apply</button><button className="secondary-btn" type="button" onClick={() => { setFilters({ startDate: '', endDate: '' }); setTimeout(load, 0); }}>Reset</button></form></section>
    {error && <div className="notice error">{error}</div>}
    {loading || !summary ? <div className="state-card"><div className="spinner" /><p>Loading financial data...</p></div> : <>
      <section className="content-grid two-one"><div className="panel-card"><div className="panel-head"><div><h3>Tax estimate</h3><p>Based on completed income in this period</p></div><span className="panel-badge">Estimate</span></div><div className="tax-big">{money(summary.tax.estimatedTax)}</div><div className="tax-summary-grid"><div><span>Taxable income</span><strong>{money(summary.tax.taxableIncome)}</strong></div><div><span>Rate / bracket</span><strong>{summary.tax.ratePercent}%</strong></div><div><span>Total income</span><strong>{money(summary.totalIncome)}</strong></div></div><p className="disclaimer">Tax calculations are for demonstration purposes only and are not professional tax advice.</p></div>
      <div className="panel-card"><div className="panel-head"><div><h3>Income by category</h3><p>Completed transactions</p></div></div><div className="category-list">{summary.byCategory.length === 0 ? <div className="empty-inline">No income recorded for this period.</div> : summary.byCategory.map((c) => <div className="category-row" key={c.category}><div className="category-copy"><strong>{c.category}</strong><span>{money(c.income)}</span></div><div className="category-track"><div className="category-fill" style={{ width: `${(c.income / maxCat) * 100}%` }} /></div></div>)}</div></div></section>
      <section className="panel-card"><div className="panel-head"><div><h3>Transactions</h3><p>{transactions.length} transaction{transactions.length === 1 ? '' : 's'} in this view</p></div></div><div className="table-wrap"><table><thead><tr><th>Date</th><th>Client</th><th>Gig</th><th>Category</th><th>Amount</th><th>Status</th></tr></thead><tbody>{transactions.length === 0 ? <tr><td colSpan="6"><div className="empty-inline">No transactions for the selected date range.</div></td></tr> : transactions.map((t) => <tr key={t._id}><td>{fmt(t.transactionDate)}</td><td>{t.client?.name || 'Client'}</td><td>{t.gig?.title || 'Gig'}</td><td>{t.category}</td><td><strong>{money(t.amount)}</strong></td><td><span className={`status-pill ${t.status}`}>{t.status}</span></td></tr>)}</tbody></table></div></section>
    </>}
  </div>;
}
