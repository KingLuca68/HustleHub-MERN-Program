import { useEffect, useState } from 'react';
import freelancerApi from '../../api/freelancerApi';

const money = (value) => `R ${Number(value || 0).toLocaleString('en-ZA', { minimumFractionDigits: 2 })}`;
const fmt = (value) => new Date(value).toLocaleDateString('en-ZA', { day: '2-digit', month: 'short', year: 'numeric' });

export default function Bookings() {
  const [bookings, setBookings] = useState([]);
  const [filter, setFilter] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState('');

  const load = () => freelancerApi.getBookings(filter).then((res) => setBookings(res.data.data)).catch((e) => setError(e.response?.data?.message || 'Unable to load bookings.'));
  useEffect(load, [filter]);

  const action = async (id, type) => {
    setBusy(id); setError('');
    try { if (type === 'accept') await freelancerApi.acceptBooking(id); if (type === 'decline') await freelancerApi.declineBooking(id); if (type === 'complete') await freelancerApi.completeBooking(id); await load(); } catch (e) { setError(e.response?.data?.message || 'Unable to update booking.'); } finally { setBusy(''); }
  };

  return <div className="dashboard-stack">
    <div className="page-intro"><div><span className="section-kicker">Client requests</span><h2>Bookings</h2><p>Review incoming work, make decisions, and complete accepted bookings to record the transaction.</p></div><select className="filter-select" value={filter} onChange={(e) => setFilter(e.target.value)}><option value="">All statuses</option><option value="pending">Pending</option><option value="accepted">Accepted</option><option value="declined">Declined</option><option value="completed">Completed</option><option value="cancelled">Cancelled</option></select></div>
    {error && <div className="notice error">{error}</div>}
    <section className="panel-card"><div className="table-wrap"><table><thead><tr><th>Client</th><th>Gig</th><th>Requested date</th><th>Amount</th><th>Status</th><th>Action</th></tr></thead><tbody>{bookings.length === 0 ? <tr><td colSpan="6"><div className="empty-inline">No bookings match this filter.</div></td></tr> : bookings.map((b) => <tr key={b._id}><td><strong>{b.client?.name || 'Client'}</strong><small>{b.client?.email || ''}</small></td><td>{b.gig?.title || 'Gig'}</td><td>{fmt(b.requestedDate)}</td><td>{money(b.amount)}</td><td><span className={`status-pill ${b.status}`}>{b.status}</span></td><td><div className="table-actions">{b.status === 'pending' && <><button className="small-btn accept" disabled={busy === b._id} onClick={() => action(b._id, 'accept')}>Accept</button><button className="small-btn decline" disabled={busy === b._id} onClick={() => action(b._id, 'decline')}>Decline</button></>}{b.status === 'accepted' && <button className="small-btn complete" disabled={busy === b._id} onClick={() => action(b._id, 'complete')}>{busy === b._id ? 'Saving...' : 'Mark Complete'}</button>}</div></td></tr>)}</tbody></table></div></section>
  </div>;
}
