import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import freelancerApi from '../../api/freelancerApi';

const money = (value) => `R ${Number(value || 0).toLocaleString('en-ZA', { minimumFractionDigits: 2 })}`;
const fmt = (value) => new Date(value).toLocaleDateString('en-ZA', { day: '2-digit', month: 'short', year: 'numeric' });

export default function GigDetails() {
  const { id } = useParams();
  const [gig, setGig] = useState(null);
  const [bookings, setBookings] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => { Promise.all([freelancerApi.getGig(id), freelancerApi.getGigBookings(id)]).then(([g, b]) => { setGig(g.data.data); setBookings(b.data.data); }).catch((e) => setError(e.response?.data?.message || 'Unable to load gig.')); }, [id]);

  if (error) return <div className="state-card error-state"><strong>{error}</strong><Link to="/freelancer/gigs" className="booking-link">← Back to gigs</Link></div>;
  if (!gig) return <div className="state-card"><div className="spinner" /><p>Loading gig...</p></div>;

  return <div className="dashboard-stack">
    <Link to="/freelancer/gigs" className="back-link">← Back to My Gigs</Link>
    <section className="panel-card detail-hero"><div><span className={`status-pill ${gig.isActive ? 'active' : 'paused'}`}>{gig.isActive ? 'Active' : 'Paused'}</span><h2>{gig.title}</h2><p>{gig.description}</p></div><div className="detail-price"><strong>{money(gig.price)}</strong><span>{gig.deliveryTime} day delivery</span></div></section>
    <section className="panel-card"><div className="panel-head"><div><h3>Booking history</h3><p>{bookings.length} booking{bookings.length === 1 ? '' : 's'} linked to this gig</p></div></div>{bookings.length === 0 ? <div className="empty-inline">No bookings have been placed for this gig yet.</div> : <div className="table-wrap"><table><thead><tr><th>Client</th><th>Requested</th><th>Amount</th><th>Status</th></tr></thead><tbody>{bookings.map((b) => <tr key={b._id}><td><strong>{b.client?.name || 'Client'}</strong><small>{b.client?.email}</small></td><td>{fmt(b.requestedDate)}</td><td>{money(b.amount)}</td><td><span className={`status-pill ${b.status}`}>{b.status}</span></td></tr>)}</tbody></table></div>}</section>
  </div>;
}
