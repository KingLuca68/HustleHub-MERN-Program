import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import freelancerApi from '../../api/freelancerApi';

const initialForm = { title: '', description: '', category: '', price: '', deliveryTime: 3 };
const money = (value) => `R ${Number(value || 0).toLocaleString('en-ZA', { minimumFractionDigits: 2 })}`;

export default function Gigs() {
  const [gigs, setGigs] = useState([]);
  const [form, setForm] = useState(initialForm);
  const [editing, setEditing] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [loading, setLoading] = useState(true);

  const load = () => { setLoading(true); freelancerApi.getGigs().then((res) => setGigs(res.data.data)).catch((e) => setError(e.response?.data?.message || 'Unable to load gigs.')).finally(() => setLoading(false)); };
  useEffect(load, []);

  const openNew = () => { setEditing(null); setForm(initialForm); setShowForm(true); setNotice(''); setError(''); };
  const openEdit = (gig) => { setEditing(gig); setForm({ title: gig.title, description: gig.description, category: gig.category, price: gig.price, deliveryTime: gig.deliveryTime }); setShowForm(true); setNotice(''); setError(''); };

  const submit = async (event) => {
    event.preventDefault(); setError(''); setNotice('');
    try {
      const payload = { ...form, price: Number(form.price), deliveryTime: Number(form.deliveryTime) };
      if (!payload.title.trim() || !payload.description.trim() || !payload.category.trim() || payload.price < 0 || payload.deliveryTime < 1) throw new Error('Please complete all fields with valid values.');
      if (editing) await freelancerApi.updateGig(editing._id, payload); else await freelancerApi.createGig(payload);
      setShowForm(false); setNotice(editing ? 'Gig updated successfully.' : 'Gig created successfully.'); load();
    } catch (e) { setError(e.response?.data?.message || e.message || 'Unable to save gig.'); }
  };

  const toggle = async (gig) => { try { await freelancerApi.updateGig(gig._id, { isActive: !gig.isActive }); setNotice(`Gig ${gig.isActive ? 'paused' : 'activated'}.`); load(); } catch (e) { setError(e.response?.data?.message || 'Unable to update gig.'); } };
  const remove = async (gig) => { if (!window.confirm(`Delete or archive “${gig.title}”? Historical booking records are preserved.`)) return; try { const res = await freelancerApi.deleteGig(gig._id); setNotice(res.data.message || 'Gig removed.'); load(); } catch (e) { setError(e.response?.data?.message || 'Unable to delete gig.'); } };

  return (
    <div className="dashboard-stack">
      <div className="page-intro"><div><span className="section-kicker">Service catalogue</span><h2>My gigs</h2><p>Publish the services clients can book, then pause them whenever your workload is full.</p></div><button className="primary-btn" onClick={openNew}>+ New Gig</button></div>
      {notice && <div className="notice success">✓ {notice}</div>}
      {error && <div className="notice error">{error}</div>}
      {loading ? <div className="state-card"><div className="spinner" /><p>Loading gigs...</p></div> : gigs.length === 0 ? (
        <div className="empty-state panel-card"><div className="empty-icon">✦</div><h3>No gigs yet</h3><p>Create your first service listing to start receiving bookings.</p><button className="primary-btn" onClick={openNew}>Create your first gig</button></div>
      ) : (
        <div className="gig-grid">
          {gigs.map((gig) => (
            <article className="gig-card" key={gig._id}>
              <div className="gig-card-top"><span className={`status-pill ${gig.isActive ? 'active' : 'paused'}`}>{gig.isActive ? 'Active' : 'Paused'}</span><span className="gig-category">{gig.category}</span></div>
              <h3>{gig.title}</h3><p>{gig.description}</p>
              <div className="gig-meta"><strong>{money(gig.price)}</strong><span>{gig.deliveryTime} day{gig.deliveryTime === 1 ? '' : 's'}</span></div>
              <div className="gig-actions"><button onClick={() => toggle(gig)} className="secondary-btn">{gig.isActive ? 'Pause' : 'Activate'}</button><button onClick={() => openEdit(gig)} className="secondary-btn">Edit</button><button onClick={() => remove(gig)} className="icon-btn danger" aria-label={`Delete ${gig.title}`}>×</button></div>
              <Link className="booking-link" to={`/freelancer/gigs/${gig._id}`}>View booking history →</Link>
            </article>
          ))}
        </div>
      )}

      {showForm && <div className="modal-backdrop" role="presentation"><div className="modal-card" role="dialog" aria-modal="true" aria-labelledby="gig-form-title">
        <div className="modal-head"><div><span className="section-kicker">Gig editor</span><h3 id="gig-form-title">{editing ? 'Edit gig' : 'Create a new gig'}</h3></div><button className="modal-close" onClick={() => setShowForm(false)}>×</button></div>
        <form onSubmit={submit} className="form-grid">
          <label>Title<input maxLength="100" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required /></label>
          <label>Category<input maxLength="60" placeholder="e.g. Design" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} required /></label>
          <label className="full">Description<textarea maxLength="2000" rows="5" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} required /></label>
          <label>Price (ZAR)<input type="number" min="0" step="0.01" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} required /></label>
          <label>Delivery time (days)<input type="number" min="1" step="1" value={form.deliveryTime} onChange={(e) => setForm({ ...form, deliveryTime: e.target.value })} required /></label>
          <div className="form-actions full"><button type="button" className="secondary-btn" onClick={() => setShowForm(false)}>Cancel</button><button className="primary-btn" type="submit">{editing ? 'Save changes' : 'Create gig'}</button></div>
        </form>
      </div></div>}
    </div>
  );
}
