import { useEffect, useState } from 'react';
import freelancerApi from '../../api/freelancerApi';

const money = (value) => `R ${Number(value || 0).toLocaleString('en-ZA', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const fmtDate = (value) => new Date(value).toLocaleDateString('en-ZA', { day: '2-digit', month: 'short' });

function IncomeChart({ data }) {
  const max = Math.max(...data.map((x) => x.income), 1);
  return (
    <div className="bar-chart" aria-label="Income over the last six months">
      {data.map((point) => (
        <div className="bar-column" key={point.month}>
          <div className="bar-value">{point.income ? money(point.income) : 'R 0'}</div>
          <div className="bar-track"><div className="bar-fill" style={{ height: `${Math.max(6, (point.income / max) * 100)}%` }} /></div>
          <span>{point.label}</span>
        </div>
      ))}
    </div>
  );
}

export default function Overview() {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    freelancerApi.getDashboard().then((res) => setData(res.data.data)).catch((err) => setError(err.response?.data?.message || 'Unable to load dashboard.'));
  }, []);

  if (error) return <div className="state-card error-state"><strong>Could not load your dashboard</strong><p>{error}</p></div>;
  if (!data) return <div className="state-card"><div className="spinner" /><p>Loading your financial workspace...</p></div>;

  const cards = [
    { label: 'Total income', value: money(data.summary.totalIncome), hint: 'All completed earnings', icon: 'R' },
    { label: 'Income this month', value: money(data.summary.monthlyIncome), hint: 'Current calendar month', icon: '↗' },
    { label: 'Pending bookings', value: data.summary.pendingBookings, hint: 'Need your attention', icon: '◫' },
    { label: 'Estimated tax', value: money(data.summary.estimatedTax), hint: 'Demonstration estimate', icon: '%' },
  ];

  return (
    <div className="dashboard-stack">
      <section className="welcome-banner">
        <div>
          <span className="section-kicker">Your business at a glance</span>
          <h2>Keep your hustle moving.</h2>
          <p>Track earnings, handle bookings, and keep an eye on your estimated tax position from one place.</p>
        </div>
        <div className="banner-pill">Financials updated live</div>
      </section>

      <section className="metric-grid">
        {cards.map((card) => (
          <div className="metric-card" key={card.label}>
            <div className="metric-icon">{card.icon}</div>
            <div className="metric-copy"><span>{card.label}</span><strong>{card.value}</strong><small>{card.hint}</small></div>
          </div>
        ))}
      </section>

      <section className="content-grid two-one">
        <div className="panel-card chart-panel">
          <div className="panel-head"><div><h3>Income trend</h3><p>Completed income over the last six months</p></div><span className="panel-badge">Income</span></div>
          <IncomeChart data={data.incomeTrend} />
        </div>
        <div className="panel-card tax-summary-card">
          <div className="panel-head"><div><h3>Tax snapshot</h3><p>Current year estimate</p></div><span className="tax-icon">%</span></div>
          <div className="tax-number">{money(data.tax.estimatedTax)}</div>
          <div className="tax-row"><span>Taxable income</span><strong>{money(data.tax.taxableIncome)}</strong></div>
          <div className="tax-row"><span>Rate applied</span><strong>{data.tax.ratePercent}%</strong></div>
          <p className="disclaimer">For demonstration purposes only. HustleHub+ does not provide professional tax advice.</p>
        </div>
      </section>

      <section className="panel-card">
        <div className="panel-head"><div><h3>Recent activity</h3><p>Your five latest bookings and payments</p></div></div>
        {data.recentActivity.length === 0 ? <div className="empty-inline">No activity yet. Your first booking will appear here.</div> : (
          <div className="activity-list">
            {data.recentActivity.map((item, index) => (
              <div className="activity-row" key={`${item.date}-${index}`}>
                <div className={`activity-dot ${item.type}`} />
                <div className="activity-copy"><strong>{item.title}</strong><span>{item.meta} · {fmtDate(item.date)}</span></div>
                {item.amount !== undefined && <strong className="activity-amount">{money(item.amount)}</strong>}
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
